# SHBACE Medical — مشروع Android Studio (Capacitor)

تطبيق **SHBACE Medical** (`com.shbace.medical`) محوَّلاً من ملف HTML واحد (19.1 MB) إلى مشروع Android Studio كامل ومنظَّم،
مع المحافظة على كل الوظائف والبيانات والتصميم، وتحسين كبير في سرعة التشغيل والذاكرة.

> **مهم — خطوة واحدة قبل الفتح:** حزم Capacitor نفسها (مصدر `@capacitor/android` والإضافات) تأتي من npm ولا تُشحن داخل الـZIP.
> نفّذ `npm install` مرة واحدة (انظر أدناه) ثم افتح مجلد `android/` في Android Studio. هذه هي الطريقة القياسية لأي مشروع Capacitor.

---

## 1) محتويات المشروع

```
ShbaceMedical/
├─ www/                         تطبيق الويب (المصدر الوحيد للحقيقة — عدّل هنا)
│  ├─ index.html                33 KB فقط: السبلاش + الهيكل + محمّل الإقلاع
│  ├─ css/core.css, late.css    كل أنماط التطبيق بنفس ترتيب الـcascade الأصلي
│  ├─ js/01..28-*.js            28 سكربت كلاسيكي بنفس ترتيب التنفيذ الأصلي (أسماؤها تدل على وظيفتها)
│  ├─ data/qbData.json          بنك الأسئلة (1718 سؤالاً) — نفس البايتات الأصلية
│  ├─ assets/img/               186 صورة (webp/png/jpg) — نفس البايتات الأصلية، دون أي إعادة ضغط
│  └─ BUILD_REPORT.json         تقرير التقسيم
├─ android/                     مشروع Android Studio (افتح هذا المجلد)
│  ├─ app/src/main/java/com/shbace/medical/MainActivity.java   (ملفك الأصلي: سبلاش، edge-to-edge، immersive، لوحة المفاتيح)
│  ├─ app/src/main/java/com/shbace/medical/ShbaceNative.java   (جديد: حفظ الملفات + الطباعة/PDF)
│  ├─ app/src/main/res/…       أيقونات بكل الكثافات + adaptive icon + styles (ملفك) + نسخ v27/v28/v29/v35
│  └─ gradlew, gradle/wrapper  Gradle 8.14.3
├─ capacitor.config.json
├─ package.json
├─ branding/                    الشعار الرسمي (لم يُعدَّل) + أيقونة Play Store 512×512
└─ tools/                       split_html.py · verify_www.py · make_icons.py
```

## 2) فتح المشروع وبناء APK

المتطلبات: **Node.js 22+** ، **Android Studio Otter (2025.2.1) أو أحدث** (يتضمن JDK 21 و Android SDK 36).

```bash
cd ShbaceMedical
npm install                 # يجلب Capacitor 8 + الإضافات (app, haptics, local-notifications)
npx cap sync android        # اختياري: يعيد توليد ملفات Gradle/الإضافات (جاهزة أصلاً)
```

ثم في Android Studio: **File ▸ Open ▸ مجلد `ShbaceMedical/android`** ← انتظر Gradle Sync ← **Build ▸ Build APK(s)**.

أو من الطرفية:

```bash
cd android
./gradlew assembleDebug     # → android/app/build/outputs/apk/debug/app-debug.apk
```

> كل عملية Build تنسخ `www/` تلقائياً إلى `app/src/main/assets/public` (مهمة `copyWebAssets` في `app/build.gradle`)،
> فلا يمكن أن يُحزَّم تطبيق ويب قديم أو ناقص. لا حاجة لتشغيل `cap copy` يدوياً.

## 3) نسخة الإصدار (AAB لـ Google Play)

1. أنشئ مفتاح التوقيع (مرة واحدة، واحتفظ به وبكلمات مروره في مكان آمن):
   ```bash
   keytool -genkeypair -v -keystore shbace-release.jks -alias shbace -keyalg RSA -keysize 2048 -validity 10000
   ```
2. انسخ `android/keystore.properties.example` إلى `android/keystore.properties` واملأه (الملف مُستبعد من git).
3. ارفع `versionCode` في `android/app/build.gradle` **إلى رقم أعلى من آخر نسخة نُشرت/ثُبّتت** (حالياً 1).
4. ```bash
   cd android && ./gradlew bundleRelease     # → app/build/outputs/bundle/release/app-release.aab
   ```

تم ضبط `targetSdk = 36` (مطلوب في Google Play منذ 31 أغسطس 2026) و`minSdk = 24`.

## 4) الحفاظ على بيانات المستخدمين الحاليين

بيانات الطلاب محفوظة في `localStorage` داخل WebView. لم يتغير أي مفتاح تخزين ولا صيغته، لذلك **لا تحتاج إلى Migration**.
حتى تبقى بياناتهم عند التحديث فوق نسخة مثبّتة: استخدم نفس `applicationId` (`com.shbace.medical`) ونفس مفتاح التوقيع،
وأبقِ `server.androidScheme = "https"` في `capacitor.config.json` (يجعل أصل الصفحة `https://localhost` كما هو الافتراضي في Capacitor الحديث).
إذا كانت نسختك السابقة تعمل بمخطط مختلف (مثلاً `http`) فغيّره هنا ليطابقها، فالأصل (origin) هو ما يحدد مكان `localStorage`.

## 5) ما الذي تغيّر على الكود الأصلي (كل شيء موثَّق ومُتحقَّق منه)

التقسيم **بلا فقدان**: الصور بنفس البايتات، وكل سكربت/نمط/JSON بنفس المحتوى والترتيب. الأداة `tools/verify_www.py` تثبت ذلك (انظر TEST_REPORT.md).
التعديلات البرمجية الوحيدة (6):

| # | الملف | التعديل | السبب |
|---|-------|---------|-------|
| 1 | `index.html` (محمّل الإقلاع) | يحمّل `js/*.js` كسكربتات خارجية بالتتابع بدل 14 MB نصاً مضمَّناً، ويجلب `data/qbData.json` بالتوازي مع السبلاش | سرعة الإقلاع والذاكرة، نفس ترتيب التنفيذ ونفس النطاق العام |
| 2 | `js/04-app-main.js` | `JOURNEY_AVATAR`: بدل `atob(data-URI)` ← ملف صورة عادي يُفك ترميزه وقت الخمول | الصورة لم تعد base64 |
| 3 | `js/04-app-main.js` | `docImg`: استخدام الصورة المستخرجة مباشرة بدل طلب `assets/doctor/*.png` غير الموجود (كان يُنتج 404 ثم يرجع للنسخة المضمَّنة) | إزالة طلب فاشل لكل صورة طبيب |
| 4 | `js/09-app-features-v6.js` | `printHTML`: داخل التطبيق يستخدم نافذة الطباعة الأصلية | WebView لا ينفّذ `window.print()` |
| 5 | `index.html` (shim) | يحوّل نقرات `<a download>` (نسخ احتياطي/ملاحظات) إلى حفظ أصلي في مجلد Downloads | WebView يتجاهل التنزيل من `blob:` |
| 6 | `index.html` (head) | `<link rel=preload>` لصور السبلاش والـCSS وأول السكربتات | ظهور أسرع للسبلاش |

التعديلان 4 و5 يعملان **فقط داخل التطبيق** (عند وجود `window.ShbaceNative`)؛ في متصفح عادي السلوك كما كان (اختُبر).

## 6) إعدادات أصلية مهمة

- **MainActivity.java**: ملفك كما هو، مع سطر واحد يسجّل `ShbaceNative`.
- **SystemBars**: في Capacitor 8 إضافة `SystemBars` المدمجة تحقن هوامش/متغيرات الـinsets؛ عُطّلت (`insetsHandling: "disable"`) لأن `MainActivity` يتولى الـinsets بنفسه (منعاً للتكرار المزدوج).
- **الأذونات** (الضرورية فقط): `INTERNET`, `POST_NOTIFICATIONS`, `RECEIVE_BOOT_COMPLETED` (إعادة جدولة الإشعارات بعد إعادة التشغيل), `VIBRATE` (الاهتزاز), `SCHEDULE_EXACT_ALARM` (حتى Android 13 فقط).
- **زر الرجوع**: يعالجه Capacitor؛ والتطبيق يستخدم `history.pushState` فيعمل الرجوع بين الشاشات، ومن الشاشة الأولى يُغلق التطبيق.
- **الأيقونة**: مولّدة من شعارك الرسمي بالتكبير/التصغير فقط (لم يُرسم من جديد). أيقونة الإشعار (قلب أبيض) رمز عام للشريط العلوي، يمكنك استبدال `res/drawable/ic_stat_shbace.xml`.
- **مدة السبلاش داخل الصفحة**: 7 ثوانٍ (`SPLASH_DURATION_MS` في `js/04-app-main.js`) — لم تُغيَّر لأنها جزء من هوية التطبيق، لكنها ثابت واحد إن رغبت بتقصيرها.

## 7) الإشعارات الفورية (Push / FCM) — غير مضمَّنة عمداً

زر Push في التطبيق يتطلب مشروع Firebase وملف `google-services.json` وخادماً. إضافة `@capacitor/push-notifications` بدونها قد تُسقط التطبيق عند التسجيل،
والتطبيق نفسه يتعامل بلطف مع غيابها. لتفعيلها: `npm i @capacitor/push-notifications` ← ضع `google-services.json` في `android/app/` ←
أضف `classpath 'com.google.gms:google-services:4.4.4'` في `android/build.gradle` و`apply plugin: 'com.google.gms.google-services'` في `app/build.gradle` ← `npx cap sync android`.
الإشعارات المحلية (معلومة طبية يومية 10:00 و22:00) مضمَّنة وتعمل بدون Firebase.

## 8) تعديل التطبيق مستقبلاً

- عدّل ملفات `www/` مباشرة (لم يعد هناك ملف HTML ضخم). `css/*.css` و`js/NN-*.js` تُحمَّل بالترتيب المكتوب في `index.html` (وسم `data-src`).
- صورة جديدة: ضعها في `www/assets/img/` واستخدم المسار `/assets/img/اسمها` (مسار جذري، يعمل من HTML وCSS وJS).
- للتجربة في المتصفح: `npm run serve` ثم افتح `http://localhost:8080` (لا تفتح `index.html` مباشرة بـ`file://` لأن `fetch` محجوب).
- لإعادة توليد `www/` من ملف HTML أحادي جديد: `python3 tools/split_html.py new-index.html www` ثم `python3 tools/verify_www.py new-index.html www`.
- لإعادة توليد الأيقونات من `branding/logo-source.png`: `python3 tools/make_icons.py`.
